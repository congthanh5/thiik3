using System.ComponentModel.DataAnnotations;

namespace finalExam.Models;

public class EmployeeViewModel
{
    public int EmployeeId { get; set; }
    [Required]
    public string EmployeeName { get; set; }
    [Required]
    public string EmployeeCode { get; set; }
    public string Rank { get; set; }
    public int DepartmentId { get; set; }
}