using System.ComponentModel.DataAnnotations;

namespace finalExam.Models;

public class DepartmentViewModel
{
    public int DepartmentId { get; set; }
    [Required]
    public string DepartmentName { get; set; }
    [Required]
    public string DepartmentCode { get; set; }
    public string Location { get; set; }
    public int NumberOfPersonals { get; set; }
}