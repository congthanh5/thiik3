using finalExam.Data;
using finalExam.Entity;
using Microsoft.EntityFrameworkCore;

namespace finalExam.Repositories;

public class EmployeeRepository: IEmployeeRepository
{
    private readonly ApplicationDbcontext _context;

    public EmployeeRepository(ApplicationDbcontext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Employee>> GetAllEmployeesAsync()
    {
        return await _context.Employee_Tbl.Include(e => e.Department).ToListAsync();
    }

    public async Task<Employee> GetEmployeeByIdAsync(int id)
    {
        return await _context.Employee_Tbl.Include(e => e.Department).FirstOrDefaultAsync(e => e.EmployeeId == id);
    }

    public async Task AddEmployeeAsync(Employee employee)
    {
        _context.Employee_Tbl.Add(employee);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateEmployeeAsync(Employee employee)
    {
        _context.Entry(employee).State = EntityState.Modified;
        await _context.SaveChangesAsync();
    }

    public async Task DeleteEmployeeAsync(int id)
    {
        var employee = await _context.Employee_Tbl.FindAsync(id);
        if (employee != null)
        {
            _context.Employee_Tbl.Remove(employee);
            await _context.SaveChangesAsync();
        }
    }
}