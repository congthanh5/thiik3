using finalExam.Data;
using finalExam.Entity;
using Microsoft.EntityFrameworkCore;

namespace finalExam.Repositories;

public class DepartmentRepository: IDepartmentRepository
{
    private readonly ApplicationDbcontext _context;

    public DepartmentRepository(ApplicationDbcontext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Department>> GetAllDepartmentsAsync()
    {
        return await _context.Department_Tbl.ToListAsync();
    }

    public async Task<Department> GetDepartmentByIdAsync(int id)
    {
        return await _context.Department_Tbl.FindAsync(id);
    }

    public async Task AddDepartmentAsync(Department department)
    {
        _context.Department_Tbl.Add(department);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateDepartmentAsync(Department department)
    {
        _context.Entry(department).State = EntityState.Modified;
        await _context.SaveChangesAsync();
    }

    public async Task DeleteDepartmentAsync(int id)
    {
        var department = await _context.Department_Tbl.FindAsync(id);
        if (department != null)
        {
            _context.Department_Tbl.Remove(department);
            await _context.SaveChangesAsync();
        }
    }
}