using finalExam.Entity;
using Microsoft.EntityFrameworkCore;

namespace finalExam.Data;

public class ApplicationDbcontext : DbContext
{
    public DbSet<Department> Department_Tbl { get; set; }
    public DbSet<Employee> Employee_Tbl { get; set; }

    public ApplicationDbcontext(DbContextOptions<ApplicationDbcontext> options)
        : base(options)
    {
    }

    public DbSet<Department> Departments { get; set; }
    public DbSet<Employee> Employees { get; set; }
}